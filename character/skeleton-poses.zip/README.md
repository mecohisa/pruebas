# Un esqueleto vectorial reutilizable

Ejecuta `npm start` o `python3 -m http.server 8000` desde esta carpeta.
El estudio está en `character/index.html`. Los SVG también se pueden abrir directamente.

Incluye un personaje transparente, 660 poses SVG, 660 PNG RGBA, 11 hojas de sprites y el código editable.
La animación se reconstruye a partir de 44 poses clave; no es un calco exacto del vídeo.
Consulta `character/README.md` para instrucciones y ejemplos de integración.
El vídeo y la escena completa quedan fuera de este paquete.
